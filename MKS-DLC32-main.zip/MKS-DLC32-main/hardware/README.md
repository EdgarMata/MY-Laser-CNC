# MKS-DLC32 Hardware
- V1.1_001
  - MKS DLC32 V1.1_001 TOP.pdf
  - MKS DLC32 V1.1_001 BOTTOM.pdf
  - MKS DLC32 V1.1_001 PIN.pdf
  - MKS DLC32 V1.1_001 SCH.pdf
  - MKS DLC32 V1.1_001 SIZE.pdf
  
- V1.1_002
  - MKS DLC32 V1.1_002 TOP.pdf
  - MKS DLC32 V1.1_002 BOTTOM.pdf
  - MKS DLC32 V1.1_002 PIN.pdf
  - MKS DLC32 V1.1_002 SCH.pdf
  - MKS DLC32 V1.1_002 SIZE.pdf
  
  change log
  - From V1.1_001 version
    - Optimize the laser circuit 
	- 001 change to 002
